﻿using System;


namespace KassaSystem
{

    class Program
    {

        static void Main(string[] args)
        {

            // Skriv in köpbelopp
            Console.Write("Skriv in Köpbelopp: ");
            int tal1 = Convert.ToInt32(Console.ReadLine());

            // Skriv in betalningssumma 
            Console.Write("Skriv in Betalningssumma: ");
            int tal2 = Convert.ToInt32(Console.ReadLine());


            // Om köpbeloppet är större än betalningssumman är betalningen otillräcklig
            if (tal1 > tal2)
            {
                Console.WriteLine("Betalningssumman är otillräcklig!");
            }
            else
            {
                // Betalningssumman - Köpbeloppet
                int rest = tal2 - tal1;

                // Räkna ut och visa rest i sedlar och mynt
                calculateRest(ref rest, 500, "sedlar");
                calculateRest(ref rest, 200, "sedlar");
                calculateRest(ref rest, 100, "sedlar");
                calculateRest(ref rest, 50, "sedlar");
                calculateRest(ref rest, 20, "sedlar");
                calculateRest(ref rest, 10, "mynt");
                calculateRest(ref rest, 5, "mynt");
                calculateRest(ref rest, 1, "mynt");


                if (rest > 0)
                {
                    Console.WriteLine("Rest: " + rest);
                }
            }

            Console.ReadLine();
        }

        static void calculateRest(ref int restchange, int denomination, string label)
        {
            int numDenomination = restchange / denomination;
            if (numDenomination > 0)
            {
                restchange %= denomination;
                Console.WriteLine("Antal av " + denomination + " " + label + ": " + numDenomination);
            }
        }
    }
}